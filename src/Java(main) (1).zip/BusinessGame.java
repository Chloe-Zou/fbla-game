import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class BusinessGame {
    private Business business;
    private Competition competition;
    private Investor investor;
    private Random random;
    private Scanner scanner;

    public static void main(String[] args) {
        BusinessGame game = new BusinessGame();
        game.start();
    }

    public void start() {
        random = new Random();
        scanner = new Scanner(System.in);

        // Initialize game objects
        business = new Business("Tech Innovators", 10000, 50, "Smart Devices");
        competition = new Competition(40, 100);
        investor = new Investor(20000, false);

        // Game introduction
        System.out.println("Welcome to the Business Game!");
        System.out.println("====================================================");
        System.out.println("You are the owner of a startup tech business, and you have the responsibility to make the correct decisions to lead your business to success!");
        System.out.println("Your business, " + business.getName() + ", is located in the heart of Silicon Valley.");
        System.out.println("You specialize in " + business.getProducts() + ", but the market is highly competitive.");
        System.out.println("Your competition, 'Tech Titans', is a well-established company with a strong foothold in the industry.");
        System.out.println("====================================================");
        System.out.println("Current Challenges:");
        System.out.println("====================================================");
        System.out.println("1. Rising Rent Costs: Due to the booming tech industry, the rent for your office space has increased by 20% this year.");
        System.out.println("This has put a strain on your finances, leaving you with only $" + business.getFunds() + " in the bank.");
        System.out.println("\n2. Declining Customer Base: Customers are increasingly opting to your competition's campaign'.");
        System.out.println("Your current popularity is " + business.getPopularity() + " (out of 100), while Tech Titans' popularity is " + competition.getPopularity() + ".");
        System.out.println("\n3. Supply Chain Issues: A recent global chip shortage has driven up the cost of producing your devices.");
        System.out.println("Your product price is currently $" + business.getPrice() + ", but your profit margins are shrinking.");
        System.out.println("====================================================");
        System.out.println("The road ahead is challenging, but with the right decisions, you can overcome these obstacles and grow your business!");

        // Game loop
        while (!business.isBankrupt() && !business.hasWon()) {
            System.out.println("\n");
            System.out.println("\n--- Week " + business.getWeekCount() + " ---");
            System.out.println("What would you like to do?");
            System.out.println("1. Raise product price");
            System.out.println("2. Lower product price");
            System.out.println("3. Launch a new product");
            System.out.println("4. Seek investment");
            System.out.println("5. Sell products");
            System.out.println("6. Run a marketing campaign");
            System.out.println("7. Hire employees");
            System.out.println("8. Check status");
            System.out.println("9. End game");

            int choice = getValidChoice(1, 9);

            switch (choice) {
                case 1:
                    raiseProductPrice();
                    break;
                case 2:
                    lowerProductPrice();
                    break;
                case 3:
                    launchNewProduct();
                    break;
                case 4:
                    seekInvestment();
                    break;
                case 5:
                    sellProducts();
                    break;
                case 6:
                    runMarketingCampaign();
                    break;
                case 7:
                    hireEmployees();
                    break;
                case 8:
                    checkStatus();
                    break;
                case 9:
                    System.out.println("You chose to end the game. Thanks for playing!");
                    return;
            }

            // Update game state
            updateGameState();
            // Trigger random event
            triggerRandomEvent();
            // Increment week count by 2
            business.incrementWeekCount(2);

            // Display business status after each choice
            checkStatus();
        }

        // End game conditions
        if (business.hasWon()) {
            System.out.println("\nCongratulations! You reached $1,000,000 and won the game!");
        } else {
            System.out.println("\nGame Over! Your business went bankrupt. Better luck next time!");
        }
    }

    private int getValidChoice(int min, int max) {
        while (true) {
            try {
                int choice = scanner.nextInt();
                if (choice >= min && choice <= max) {
                    return choice;
                } else {
                    System.out.println("Invalid choice. Please enter a number between " + min + " and " + max + ".");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next(); // Clear the invalid input
            }
        }
    }

    private void raiseProductPrice() {
        System.out.println("By how much would you like to raise the price? (Enter a number between 5 and 50):");
        int raiseAmount = getValidChoice(5, 50);

        business.raisePrice(raiseAmount);
        System.out.println("\nYou raised the price of your products by $" + raiseAmount + ".");

        // Risk of customer decline
        int riskFactor = random.nextInt(100);
        if (riskFactor < raiseAmount) {
            System.out.println("Customers are outraged by the steep price increase! Many are switching to your competition.");
            int popularityLoss = 20;
            business.setPopularity(business.getPopularity() - popularityLoss);
            competition.setPopularity(competition.getPopularity() + 10);
            System.out.println("Your popularity decreased by " + popularityLoss + ", and your funds decreased by $" + (popularityLoss * 100) + ".");
            business.deductFunds(popularityLoss * 100);
        } else {
            System.out.println("Customers are slightly annoyed but continue to buy your products.");
            int popularityLoss = 5;
            business.setPopularity(business.getPopularity() - popularityLoss);
            System.out.println("Your popularity decreased by " + popularityLoss + ", and your funds decreased by $" + (popularityLoss * 100) + ".");
            business.deductFunds(popularityLoss * 100);
        }

        // Competition Reaction
        System.out.println("Tech Titans notices your price increase and decides to lower their prices to attract more customers.");
        competition.lowPrice(10);
        System.out.println("Tech Titans' price is now $" + competition.getPrice() + ".");

        // Revenue calculation
        int revenue = business.calculateRevenue();
        business.addFunds(revenue);
        System.out.println("You earned $" + revenue + " this week.");
    }

    private void lowerProductPrice() {
        System.out.println("By how much would you like to lower the price? (Enter a number between 5 and 50):");
        int lowerAmount = getValidChoice(5, 50);

        business.lowerPrice(lowerAmount);
        System.out.println("\nYou lowered the price of your products by $" + lowerAmount + ".");

        // Risk of reduced profit margins
        int riskFactor = random.nextInt(100);
        if (riskFactor < 30) {
            System.out.println("The price reduction has severely impacted your profit margins.");
            System.out.println("You struggle to cover production costs, and your funds take a hit.");
            business.deductFunds(1000);
        } else {
            System.out.println("Customers appreciate the lower prices and continue to support your business.");
            int popularityGain = 5;
            business.setPopularity(business.getPopularity() + popularityGain);
            System.out.println("Your popularity increased by " + popularityGain + ", and your funds increased by $" + (popularityGain * 100) + ".");
            business.addFunds(popularityGain * 100);
        }

        // Competition Reaction
        System.out.println("Tech Titans sees your price drop and responds by launching a new marketing campaign.");
        System.out.println("Their popularity increases by 10.");
        competition.setPopularity(competition.getPopularity() + 10);

        // Revenue calculation
        int revenue = business.calculateRevenue();
        business.addFunds(revenue);
        System.out.println("You earned $" + revenue + " this week.");
    }

    private void launchNewProduct() {
        System.out.println("What would you like to name your new product?");
        scanner.nextLine();
        String newProduct = scanner.nextLine();

        business.launchNewProduct(newProduct);
        System.out.println("\nYou launched a new product: " + newProduct + "!");

        // Risk of product failure
        int riskFactor = random.nextInt(100);
        if (riskFactor < 20) {
            System.out.println("The new product launch was a disaster! Customers complain about quality issues.");
            int popularityLoss = 15;
            business.setPopularity(business.getPopularity() - popularityLoss);
            System.out.println("Your popularity decreased by " + popularityLoss + ", and your funds decreased by $" + (popularityLoss * 100) + ".");
            business.deductFunds(popularityLoss * 100);
        } else {
            System.out.println("Customers are excited about your new product! Social media buzzes with positive reviews.");
            int popularityGain = 20;
            business.setPopularity(business.getPopularity() + popularityGain);
            System.out.println("Your popularity increased by " + popularityGain + ", and your funds increased by $" + (popularityGain * 100) + ".");
            business.addFunds(popularityGain * 100);
        }

        // Competition Reaction
        System.out.println("Tech Titans feels threatened by your new product and responds by lowering their prices.");
        competition.lowPrice(15);
        System.out.println("Tech Titans' price is now $" + competition.getPrice() + ".");

        // Revenue calculation
        int revenue = business.calculateRevenue();
        business.addFunds(revenue);
        System.out.println("You earned $" + revenue + " this week.");
    }

    private void seekInvestment() {
        System.out.println("How much investment are you seeking? (Enter a number between 1000 and 10000):");
        int investmentAmount = getValidChoice(1000, 10000);

        if (investor.isInvesting()) {
            System.out.println("\nYou already have an investor. They are not willing to invest more at this time.");
            return;
        }

        investor.invest(investmentAmount, true);
        business.addFunds(investmentAmount);
        System.out.println("\nYou successfully secured an investment of $" + investmentAmount + "!");

        // Risk of investor interference
        int riskFactor = random.nextInt(100);
        if (riskFactor < 40) {
            System.out.println("The investor demands a say in your business decisions, limiting your freedom.");
            int popularityLoss = 10;
            business.setPopularity(business.getPopularity() - popularityLoss);
            System.out.println("Your popularity decreased by " + popularityLoss + ", and your funds decreased by $" + (popularityLoss * 100) + ".");
            business.deductFunds(popularityLoss * 100);
        } else {
            System.out.println("The investment helps stabilize your finances and boosts your business.");
            int popularityGain = 10;
            business.setPopularity(business.getPopularity() + popularityGain);
            System.out.println("Your popularity increased by " + popularityGain + ", and your funds increased by $" + (popularityGain * 100) + ".");
            business.addFunds(popularityGain * 100);
        }

        // Competition Reaction
        System.out.println("Tech Titans sees your investment as a threat and responds by increasing their marketing budget.");
        System.out.println("Their popularity increases by 15.");
        competition.setPopularity(competition.getPopularity() + 15);

        // Revenue calculation
        int revenue = business.calculateRevenue();
        business.addFunds(revenue);
        System.out.println("You earned $" + revenue + " this week.");
    }

    private void sellProducts() {
        System.out.println("How many units would you like to sell? (Enter a number between 10 and 100):");
        int unitsSold = getValidChoice(10, 100);

        // Update units sold
        business.updateUnitsSold(unitsSold);

        // Revenue calculation
        int revenue = business.calculateRevenue();
        business.addFunds(revenue);
        System.out.println("\nYou sold " + unitsSold + " units of your product, earning $" + revenue + "!");

        // Risk of overproduction
        int riskFactor = random.nextInt(100);
        if (riskFactor < 10) {
            System.out.println("You overproduced and now have excess inventory. Storage costs are eating into your profits.");
            business.deductFunds(500);
        } else {
            System.out.println("Sales are steady, and your business is thriving.");
        }

        // Competition Reaction
        System.out.println("Tech Titans notices your increased sales and responds by launching a new product.");
        System.out.println("Their popularity increases by 10.");
        competition.setPopularity(competition.getPopularity() + 10);
    }

    private void runMarketingCampaign() {
        System.out.println("You decide to run a marketing campaign to boost your popularity.");
        int cost = 2000;
        if (business.getFunds() >= cost) {
            business.deductFunds(cost);
            int popularityGain = 15;
            business.setPopularity(business.getPopularity() + popularityGain);
            System.out.println("Your popularity increased by " + popularityGain + ", and your funds decreased by $" + cost + ".");
        } else {
            System.out.println("You don't have enough funds to run a marketing campaign.");
        }
    }

    private void hireEmployees() {
        System.out.println("You decide to hire new employees to improve productivity.");
        int cost = 3000;
        if (business.getFunds() >= cost) {
            business.deductFunds(cost);
            int productivityGain = 10;
            business.setProductivity(business.getProductivity() + productivityGain);
            System.out.println("Your productivity increased by " + productivityGain + ", and your funds decreased by $" + cost + ".");
        } else {
            System.out.println("You don't have enough funds to hire new employees.");
        }
    }

    private void checkStatus() {
        System.out.println("\n--- Business Status ---");
        System.out.println("Funds: $" + business.getFunds());
        System.out.println("Popularity: " + business.getPopularity() + " (out of 100)");
        System.out.println("Competition Popularity: " + competition.getPopularity() + " (out of 100)");
        System.out.println("Product: " + business.getProducts());
        System.out.println("Product Price: $" + business.getPrice());
        System.out.println("Units Sold: " + business.getUnitsSold());
        System.out.println("Week: " + business.getWeekCount());
    }

    private void updateGameState() {
        // Random market trends
        int popularityChange = random.nextInt(11) - 5; // Random change between -5 and +5
        business.setPopularity(business.getPopularity() + popularityChange);
        if (popularityChange > 0) {
            System.out.println("\nMarket trends are favorable! Your popularity increased by " + popularityChange + ", and your funds increased by $" + (popularityChange * 100) + ".");
            business.addFunds(popularityChange * 100);
        } else if (popularityChange < 0) {
            System.out.println("\nMarket trends are unfavorable! Your popularity decreased by " + (-popularityChange) + ", and your funds decreased by $" + (-popularityChange * 100) + ".");
            business.deductFunds(-popularityChange * 100);
        }

        // Random competitor actions
        int competitorAction = random.nextInt(3);
        if (competitorAction == 1) {
            competition.raisePrice(5);
            System.out.println("\nYour competition raised their prices!");
        } else if (competitorAction == 2) {
            competition.lowPrice(5);
            System.out.println("\nYour competition lowered their prices!");
        }
    }

    private void triggerRandomEvent() {
        int eventChance = random.nextInt(100);
        if (eventChance < 30) {
            int eventType = random.nextInt(4);
            switch (eventType) {
                case 0:
                    System.out.println("\nRandom Event: Competitor Launches New Product");
                    System.out.println("Your competition, Tech Titans, has launched a new product!");
                    System.out.println("Customers are flocking to their business, and your sales drop.");
                    business.setPopularity(business.getPopularity() - 10);
                    competition.setPopularity(competition.getPopularity() + 15);
                    System.out.println("Your popularity decreased by 10, and your funds decreased by $1000.");
                    business.deductFunds(1000);
                    break;
                case 1:
                    System.out.println("\nRandom Event: Viral Marketing Campaign");
                    System.out.println("Your business goes viral on social media!");
                    System.out.println("Customers are excited about your products, and your popularity soars.");
                    business.setPopularity(business.getPopularity() + 20);
                    System.out.println("Your popularity increased by 20, and your funds increased by $2000.");
                    business.addFunds(2000);
                    break;
                case 2:
                    System.out.println("\nRandom Event: Supply Chain Disruption");
                    System.out.println("A global supply chain disruption has increased your production costs.");
                    System.out.println("Your funds take a hit, and your profit margins shrink.");
                    business.deductFunds(2000);
                    break;
                case 3:
                    System.out.println("\nRandom Event: Positive Media Coverage");
                    System.out.println("A prominent tech magazine features your business in their latest issue.");
                    System.out.println("Your popularity increases, and new customers are drawn to your products.");
                    business.setPopularity(business.getPopularity() + 15);
                    System.out.println("Your popularity increased by 15, and your funds increased by $1500.");
                    business.addFunds(1500);
                    break;
            }
        }
    }
}